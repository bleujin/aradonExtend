({
	loadingState: "Loading...",
	errorState: "Sorry, an error occurred"
})
